# create-seo-builder

Scaffold SEO Builder route wrappers for an existing Next.js + Payload CMS project.

## Usage

```bash
npx create-seo-builder@latest [target-directory]
```

Or:

```bash
npm create seo-builder@latest [target-directory]
```

Examples:

```bash
npx create-seo-builder@latest .
npx create-seo-builder@latest ./my-app
```

## After scaffolding

Install SEO Builder packages in your project:

```bash
npm install @seo-builder/core @seo-builder/payload-plugin @seo-builder/ui @seo-builder/next
```

Then follow [PACKAGE_INSTALLATION.md](https://github.com/AliWarraich33621013/SEO_Builder/blob/main/PACKAGE_INSTALLATION.md).

## Repository

https://github.com/AliWarraich33621013/SEO_Builder
